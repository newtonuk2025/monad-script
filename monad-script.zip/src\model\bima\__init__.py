from .instance import Bima

__all__ = ["Bima"]


