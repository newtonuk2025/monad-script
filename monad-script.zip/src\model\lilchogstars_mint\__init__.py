from .instance import Lilchogstars

__all__ = ["Lilchogstars"]