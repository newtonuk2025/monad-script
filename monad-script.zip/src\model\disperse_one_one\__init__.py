from .instance import DisperseOneOne

__all__ = ["DisperseOneOne"]
