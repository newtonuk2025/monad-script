from .instance import Demask

__all__ = ["Demask"]