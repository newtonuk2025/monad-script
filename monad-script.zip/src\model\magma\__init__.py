from .constants import STAKE_ABI, STAKE_ADDRESS
from .instance import Magma

__all__ = ["Magma", "STAKE_ABI", "STAKE_ADDRESS"]
