from .instance import Shmonad

__all__ = ["Shmonad"]

