from .instance import Monadking

__all__ = ["Monadking"]
