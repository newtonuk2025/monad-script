SEPOLIA_EXPLORER_URL = "https://sepolia.etherscan.io/tx/0x"
SEPOLIA_RPC_URL = "https://sepolia.drpc.org/"
MONAD_SEPOLIA_ETHEREUM_ADDRESS = "0x836047a99e11F376522B447bffb6e3495Dd0637c"